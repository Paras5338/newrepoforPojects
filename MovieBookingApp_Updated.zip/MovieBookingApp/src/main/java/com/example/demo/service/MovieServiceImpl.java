package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exceptions.MovieIdAlreadyExistsExceptions;
import com.example.demo.model.Movie;
import com.example.demo.repository.MovieRepository;

@Service
public class MovieServiceImpl implements MovieService
{
	@Autowired
	private MovieRepository MovieRepo;
	

	@Override
	public List<Movie> getAllMovies(){
		
		List<Movie> Movielist = MovieRepo.findAll();
		if(Movielist !=null && Movielist.size()> 0)
		{
			return Movielist;
		}
		else
			return null;
		
	}

	@Override
	public Movie addMovie(Movie movie) throws MovieIdAlreadyExistsExceptions
	{
		Optional<Movie> opMovie = MovieRepo.findById(movie.getMovieId());
		if(opMovie.isPresent())
		{
			throw new MovieIdAlreadyExistsExceptions();
		}
		else
			return MovieRepo.saveAndFlush(movie);
	}

	@Override
	public boolean updateMovie(Movie movie) {
		Movie Movie1 = MovieRepo.getById(movie.getMovieId());
		
		if(Movie1 !=null)
		{
			Movie1.setMoviePrice(movie.getMoviePrice());
			MovieRepo.saveAndFlush(Movie1);
			return true;
		}
		return false;
		
	}

	@Override
	public boolean deleteMovie(int bid) {
		MovieRepo.deleteById(bid);
		return true;
	}

	@Override
	public Movie getMovieById(int bid) {
		
		Optional <Movie> movie = MovieRepo.findById(bid);
		if(movie.isPresent())
		{
			return movie.get();
		}
		return null;
	}

}
