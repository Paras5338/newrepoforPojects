package com.example.demo.service;

import java.util.Set;

import com.example.demo.model.Ticket;

public interface TicketService 
{
	public Set<Ticket> getAllTickets(int movieId);
	public boolean addTicket(Ticket ticket);
	public boolean deleteTicket(int movieId);

}
