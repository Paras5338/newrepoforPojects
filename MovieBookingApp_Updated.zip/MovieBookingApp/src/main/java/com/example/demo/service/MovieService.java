package com.example.demo.service;

import java.util.List;

import com.example.demo.exceptions.MovieIdAlreadyExistsExceptions;
import com.example.demo.model.Movie;

public interface MovieService 
{

	public List<Movie> getAllMovies();
	
	public Movie addMovie(Movie movie) throws MovieIdAlreadyExistsExceptions;
	
	public boolean updateMovie(Movie movie);
	
	public boolean deleteMovie(int bid);
	
	public Movie getMovieById(int bid);
	
	
}
