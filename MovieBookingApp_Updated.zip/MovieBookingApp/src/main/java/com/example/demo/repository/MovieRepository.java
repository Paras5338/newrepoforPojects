package com.example.demo.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Movie;

@Repository
@Transactional
public interface MovieRepository extends JpaRepository<Movie, Integer> 
{
	@Modifying
	@Query(value="select r from Movie r where r.movieId = :movieId")
	public Movie getById(int movieId);

}
