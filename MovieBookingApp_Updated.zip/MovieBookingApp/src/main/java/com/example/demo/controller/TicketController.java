package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Movie;
import com.example.demo.model.Ticket;
import com.example.demo.service.MovieService;
import com.example.demo.service.TicketService;

@RestController
@RequestMapping("api/v1/Ticket")
public class TicketController 
{
	@Autowired
	private TicketService rs;
	
	@Autowired
	private MovieService bs;
	
	
	@PostMapping("/add/{bid}")    // @RequestParam
	public ResponseEntity<?> addTicket(@PathVariable("bid") int bid, @RequestBody Ticket ticket)
	{
		Movie Movieexists = bs.getMovieById(bid);
		if(Movieexists!=null)
		{
			Movieexists.setTicketName(ticket.getTicketName());//Ticket name is updated in TicketName column in  Movie table
			ticket.setTicketName(ticket.getTicketName());//Ticket name is added in Ticket table
			ticket.setMovie_id_fk(ticket.getMovie_id_fk());
			ticket.setIssueAt(ticket.getIssueAt());
			
			if(bs.updateMovie(Movieexists) && rs.addTicket(ticket))
			{
				return new ResponseEntity<Ticket>(ticket, HttpStatus.CREATED);
			}
			
			
		}
		return new ResponseEntity<String>("Movie Ticket name cannot be added", HttpStatus.INTERNAL_SERVER_ERROR);
		
	}
			
	

}
