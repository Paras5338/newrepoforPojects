package com.example.demo.controller;

import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exceptions.MovieIdAlreadyExistsExceptions;
import com.example.demo.model.Movie;
import com.example.demo.model.Ticket;
import com.example.demo.response.ResponseHandler;
import com.example.demo.service.MovieService;
import com.example.demo.service.TicketService;

import io.swagger.v3.oas.annotations.Hidden;

@RestController
@RequestMapping("api/v1")
public class MovieController
{
	@Autowired
	private MovieService movieService;
	
	@Autowired
	private TicketService rs;
	
	@GetMapping("/getAllMovies")
	public ResponseEntity<?> getAllMovies()
	{
		List<Movie> movielist = movieService.getAllMovies();
		
		if(movielist !=null)
		{
			//return new ResponseEntity<List<Movie>>(movielist, HttpStatus.OK);
			
		//return ResponseHandler.generateResponse("Succesfully fetched the movielist", HttpStatus.OK, movielist);
			
			for(Movie b :movielist)
			{
				Set<Ticket> ticketlist = rs.getAllTickets(b.getMovieId());
				b.setTicketList(ticketlist);
			}
			
			CacheControl cacheControlObj = CacheControl.maxAge(30, TimeUnit.MINUTES);
			return ResponseEntity.ok().cacheControl(cacheControlObj)
					.body(ResponseHandler.generateResponse("Succesfully fetched the movielist", HttpStatus.OK, movielist));
		}
		return new ResponseEntity<String>("movielist is empty", HttpStatus.NO_CONTENT);
		
	}
	
	@PostMapping("/addmovie")
	public ResponseEntity<?> addmovie(@RequestBody Movie movie) throws MovieIdAlreadyExistsExceptions
	{
		if(movieService.addMovie(movie)!=null)
		{
			return new ResponseEntity<Movie>(movie, HttpStatus.CREATED);
		}
		
		return new ResponseEntity<String>("movie object is null", HttpStatus.NO_CONTENT);
	}
	
	@DeleteMapping("/delete/{bid}")
	public ResponseEntity<?> deletemovie(@PathVariable ("bid") int bid)
	{
		if(movieService.deleteMovie(bid))
		{
			return new ResponseEntity<String>("Movie got deleted successfully",HttpStatus.OK);
		}
		
		return new ResponseEntity<String>("Movie did not get deleted ",HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@Hidden
	@PutMapping("/updatemovie")
	public ResponseEntity<?> updatemovie(@RequestBody Movie movie)
	{
		if(movieService.updateMovie(movie))
		{
			return new ResponseEntity<String>("Movie got updated successfully",HttpStatus.OK);
		}
		
		return new ResponseEntity<String>("Movie updation failed",HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@GetMapping("/movieById/{bid}")
	public ResponseEntity<?> getmovieById(@PathVariable("bid") int bid)
	{
		Movie movieexists = movieService.getMovieById(bid);
		if(movieexists !=null)
		{
			
			Set<Ticket> ticketlist = rs.getAllTickets(movieexists.getMovieId());
			movieexists.setTicketList(ticketlist);
			return new ResponseEntity<Movie>(movieexists, HttpStatus.OK);
		}
		return new ResponseEntity<String>("Movie record does not exist",HttpStatus.NO_CONTENT);
	}
	

}






