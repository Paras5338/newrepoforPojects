package com.example.demo.model;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Movie 
{
	@Id
	private int movieId;
	private String movieName;
	private double moviePrice;
	private String ticketName;
	
	@OneToMany(targetEntity= Ticket.class)
	public Set<Ticket> ticketList;

	public int getMovieId() {
		return movieId;
	}

	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public double getMoviePrice() {
		return moviePrice;
	}

	public void setMoviePrice(double moviePrice) {
		this.moviePrice = moviePrice;
	}

	public String getTicketName() {
		return ticketName;
	}

	public void setTicketName(String ticketName) {
		this.ticketName = ticketName;
	}

	public Set<Ticket> getTicketList() {
		return ticketList;
	}

	public void setTicketList(Set<Ticket> ticketList) {
		this.ticketList = ticketList;
	}

	@Override
	public String toString() {
		return "Movie [movieId=" + movieId + ", movieName=" + movieName + ", moviePrice=" + moviePrice + ", ticketName="
				+ ticketName + ", ticketList=" + ticketList + "]";
	}
	
	
	
	
}
