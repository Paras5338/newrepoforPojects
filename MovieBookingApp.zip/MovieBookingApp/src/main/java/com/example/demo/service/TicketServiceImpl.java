package com.example.demo.service;

import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Ticket;
import com.example.demo.repository.TicketRepository;

@Service
public class TicketServiceImpl implements TicketService{
	@Autowired
	private TicketRepository TicketRepo;

	@Override
	public Set<Ticket> getAllTickets(int movieId) {
		
		Set<Ticket> Ticketlist = TicketRepo.getTicketList(movieId);
		return Ticketlist;
	}

	@Override
	public boolean addTicket(Ticket ticket) {
		
		
			Ticket TicketObj = new Ticket();
			TicketObj.setTicketName(ticket.getTicketName());
			TicketObj.setIssueAt(ticket.getIssueAt());
			TicketObj.setMovie_id_fk(ticket.getMovie_id_fk());
			TicketRepo.saveAndFlush(TicketObj);
			return true;
			
		}
		/*Optional<Ticket> rObj = TicketRepo.findById(Ticket.getmovie_id_fk());
		if(rObj.isPresent())
		{

			TicketRepo.saveAndFlush(Ticket);
			return true;
		}
		return false;*/
	

	@Override
	public boolean deleteTicket(int movieId) {
		TicketRepo.deleteTicketData(movieId);
		return true;
	}

}
